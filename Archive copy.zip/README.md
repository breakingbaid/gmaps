# GoogleMaps

In this repository you will come to know about following things-

How to use google map in your project
How to drow path between two points using google maps in android. 
How to get current location on google maps
How to add market on maps
How to get location on maps
How to get longitude and latitude of any position
How to form url to get data from google api
How to get data from google api
How to parse the data recuived form google api
and lot more..

If you want to run the project directly then add your google map api key in google_maps_api.xml 


<a href="https://imgflip.com/gif/1y5b2n"><img src="https://i.imgflip.com/1y5b2n.gif" title="made at imgflip.com"/></a>
